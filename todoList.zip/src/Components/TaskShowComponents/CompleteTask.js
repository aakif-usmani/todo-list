import React from "react";

import "./CompleteTask.css";

const CompleteTask = () => {
    return (
        <div className=" completeTask">
            {/* <p>
                complete tasks
            </p> */}
        </div>
    )
}

export default CompleteTask;