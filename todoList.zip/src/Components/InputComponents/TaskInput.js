import React from "react";

import "./TaskInput.css";

const TaskInput = () => {
    return(
        <div>
            <input placeholder="ADD TASK" type="text" className="input-top" />
        </div>
    )
}

export default TaskInput;