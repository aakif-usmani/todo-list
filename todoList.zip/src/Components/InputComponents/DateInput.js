import react from 'react';

import './DateInput.css';

const DateInput = () => {
    return (
        <div>
            <input type="date" className="input-top" placeholder="TIME"/>
        </div>
    )
}

export default DateInput;