import react from 'react';

import './DateInput.css';

const TimeInput = () => {
    return (
        <div>
            <input type="time" className="input-top" placeholder="TIME"/>
        </div>
    )
}

export default TimeInput;